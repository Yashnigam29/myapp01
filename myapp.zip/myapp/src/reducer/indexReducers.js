import { combineReducers } from 'redux';
import data from './update-reducer';

export default combineReducers({
    data
});