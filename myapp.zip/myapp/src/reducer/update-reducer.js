const initialState={
    tokenValue:'',
    isLoggedIn:false,
}

export default function data(prevState = initialState, action ){
    switch(action.type){
        case "SET_TOKEN":
        return {
            ...prevState,
            tokenValue: action.payload,

        }
        default:
            return prevState;
    }
}