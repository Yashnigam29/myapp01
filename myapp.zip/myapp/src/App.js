import React,{Component} from "react";
import { connect } from "react-redux";
import { Redirect, Route, Router, Switch } from "react-router";
import { bindActionCreators } from "redux";
import LoginForm from "./component/LoginForm"
import {setIsLoggedIn} from "./actions/action";
import { history } from "./history/history";
import signup from "./component/signup";
import Welcomepage from "./component/Welcomepage";

const mapStateToProps = state =>{
  return{
    data:state.data
  }
}

const mapDispatchToProps= dispatch =>
bindActionCreators({
  setIsLoggedIn
},
dispatch
);

class App extends Component{
  constructor(props){
    super(props);
  }
  render(){
   const{
     data: {
       isLoggedIn = false,
     } ={},
   } =this.props;

   return(
     
    <React.Fragment>
      <Router history={history}>
      <div className="container" className="window-padding">
        <div className="row">
          <div className="col-md-12">
             <Switch>
                 <Redirect exact from="/" to="/login" />
                 <Route path="/login" exact component={LoginForm} />
                 <Route path="/signup" exact component={signup} />
                 <Route path="/changepassword" exact component={LoginForm} />
                 <Route path="/welcomepage" exact component={Welcomepage} />

             </Switch>
          </div>
        </div>
      </div>
      </Router>
    </React.Fragment>
    
  )
  }

 
}
export default connect(mapStateToProps,mapDispatchToProps)(App);
