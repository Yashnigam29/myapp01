export function setIsLoggedIn(response){
    return{
        type:'SET_LOGGED_IN',
        payload: response
    }
}

export function setTokenInStore(tokenValue){
    return{
        type:'SET_TOKEN',
        payload: tokenValue
    }
}