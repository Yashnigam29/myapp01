const createHistory =require("history").createBrowserHistory;

export const history =createHistory({
    basename: "/myapp"
})