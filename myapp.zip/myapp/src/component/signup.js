import React,{Component} from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { bindActionCreators } from "redux";
import {setIsLoggedIn, setTokenInStore } from "../actions/action";
import axios from "axios";

const mapStateToProps = state =>{
  return{
    data:state.data
  }
}

const mapDispatchToProps= dispatch =>
bindActionCreators({
    setIsLoggedIn,
    setTokenInStore
},
dispatch
);

class signup extends Component{
  constructor(props){
    super(props);
    this.state ={
        username: "",
        password: "",
        email: "",
        confirmpassword: "",
        show: false
    },
    
    this.onChangeEvent=this.onChangeEvent.bind(this);
  }
  onChangeEvent(event){
      this.setState({ [event.target.name]: event.target.value});
  }

  onClicksignup(e){
 event.preventDefault();
 axios.post(`http://localhost:3003/api/register`,{username:this.state.username,password:this.state.password,email:this.state.email,confirmpassword:this.state.confirmpassword})
     .then(function(response){
         console.log(response);
         if(response.data.status === 200)
              this.setState({show:true});
     })
     .catch(function(error){
         console.log(error);
     })
}

  render(){
   return(
     <div className="user-login col-md-6 offset-md-3 text-center">
         {this.state.errormessage &&(
             <div className="alery alert-danger" role="alert">
                 {this.state.errormessage}
                 </div>
         )}
         <form name="Form">
             <div className="card borderClass">
                 <div className="user-heading">
                     <h3>Signup  Page</h3>
                 </div>
                 <div className="login-block">
                     <div className="form-group text-left" >
                         <label htmlFor="email">Username:</label>
                         <input type="text" placeholder="please enter username" id="username" name="username"
                          className="form-control" value={this.state.username} onChange={event => this.onChangeEvent(event)}/>

                     </div>
                     <div className="form-group text-left" >
                         <label htmlFor="password"> Password:</label>
                         <input type="text" placeholder="please enterpassword" id="password" name="password"
                          className="form-control" value={this.state.password} onChange={event => this.onChangeEvent(event)}/>

                     </div>
                     <div className="form-group text-left" >
                         <label htmlFor="password"> Confirm Password:</label>
                         <input type="text" placeholder="please re-enterpassword" id="confirmpassword" name="confirmpassword"
                          className="form-control" value={this.state.confirmpassword} onChange={event => this.onChangeEvent(event)}/>

                     </div>
                     <div className="form-group text-left" >
                         <label htmlFor="password"> email:</label>
                         <input type="text" placeholder="please enter email" id="email" name="email"
                          className="form-control" value={this.state.email} onChange={event => this.onChangeEvent(event)}/>

                     </div>
                     <div className="container login-button">
                         <div className="row">
                             <div className="col-md-12">
                                 <input type="submit" id="btnSubmit" className="btn btn-success btn-block" value="signup"
                                 onClick={e => this.onClicksignup(e)}  />
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </form>

     </div>
 
    
  )
  }

 
}
export default connect(mapStateToProps,mapDispatchToProps)(signup);
