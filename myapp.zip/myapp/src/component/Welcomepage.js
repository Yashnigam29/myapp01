
import React,{Component} from "react";
import { connect } from "react-redux";

import { bindActionCreators } from "redux";
import {setIsLoggedIn, setTokenInStore } from "../actions/action";

const mapStateToProps = state =>{
  return{
    data:state.data
  }
}

const mapDispatchToProps= dispatch =>
bindActionCreators({
    setIsLoggedIn,
    setTokenInStore
},
dispatch
);

class welcomepage extends Component{
  constructor(props){
    super(props);
    
    }

  
 
  render(){
   return(
     <div className="user-login col-md-6 offset-md-3 text-center">
         <h1>Welcome everyone</h1>

         <p>You hale logined successfully</p>

     </div>
 
    
  )
  }

 
}
export default connect(mapStateToProps,mapDispatchToProps)(welcomepage);
