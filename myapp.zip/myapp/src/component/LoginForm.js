import React,{Component} from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { bindActionCreators } from "redux";
import {setIsLoggedIn, setTokenInStore } from "../actions/action";
import axios from "axios";

const mapStateToProps = state =>{
  return{
    data:state.data
  }
}

const mapDispatchToProps= dispatch =>
bindActionCreators({
    setIsLoggedIn,
    setTokenInStore
},
dispatch
);

class LoginForm extends Component{
  constructor(props){
    super(props);
    this.state ={
        username: "",
        password: "",
        token: "",
        errormessage: "",
    }
    this.onChangeEvent=this.onChangeEvent.bind(this);
  }
  onChangeEvent(event){
      this.setState({ [event.target.name]: event.target.value});
  }

  onClickLogin(e){
  e.preventDefault();
  if(this.state.username !== "" && this.state.password !=="")
  {
           axios.post(`http://localhost:3003/api/login`,{username:this.state.username,password:this.state.password})
              .then(res =>{
                  const {token =""}=res;
                  if(token !=="")
                  {
                      this.props.setTokenInStore(token);
                      this.props.setIsLoggedIn(true);
                      this.props.history.push("/welcomepage")
                  }
              })
              .catch(err =>{
                  this.setState({
                      errormessage: "Invalid credentials"
                  });
              });
  }
  else{
    this.setState({
        errormessage: "Please fill both userid and password"
    });
  }
  }

  render(){
   return(
     <div className="user-login col-md-6 offset-md-3 text-center">
         {this.state.errormessage &&(
             <div className="alery alert-danger" role="alert">
                 {this.state.errormessage}
                 </div>
         )}
         <div class="navlist-right">
            <Link to={{pathname:"/signup",
                                state:{
                                    isRoutingValid: true
                                }
                            }}
                            id="ChangePassword"
                            >Signup</Link>
         </div>
         <form name="Form">
             <div className="card borderClass">
                 <div className="user-heading">
                     <h3>Login Page</h3>
                 </div>
                 <div className="login-block">
                     <div className="form-group text-left" >
                         <label htmlFor="email">Username:</label>
                         <input type="text" placeholder="User ID" id="username" name="username"
                          className="form-control" value={this.state.username} onChange={event => this.onChangeEvent(event)}/>

                     </div>
                     <div className="form-group text-left" >
                         <label htmlFor="password"> Password:</label>
                         <input type="text" placeholder="password" id="password" name="password"
                          className="form-control" value={this.state.password} onChange={event => this.onChangeEvent(event)}/>

                     </div>
                     <div className="form-group text-left" >
                           
                                <Link to={{pathname:"/changepassword",
                                state:{
                                    isRoutingValid: true
                                }
                            }}
                            id="ChangePassword"
                            >ChangePassword</Link>
                           
                        </div>
                     <div className="container login-button">
                         <div className="row">
                             <div className="col-md-12">
                                 <input type="submit" id="btnSubmit" className="btn btn-success btn-block" value="Login"
                                 onClick={e => this.onClickLogin(e)}  />
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </form>

     </div>
 
    
  )
  }

 
}
export default connect(mapStateToProps,mapDispatchToProps)(LoginForm);
