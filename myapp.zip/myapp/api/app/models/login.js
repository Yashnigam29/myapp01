var mongoose= require('mongoose');
var Schema=mongoose.Schema;


var LoginSchema= new Schema({
    username:{
        type:String,
        required:'please provide username'
    },
    password:{
        type:String,
        required:'please provide password'
    },
    confirm_password:{
        type:String,
        required:'please provide the confirm password',
        validate:[passwordConfirm,'password and confirm password']
    },
    email:{
        type:String,
        trim:true,
        lowercase:true,
        required:'please provide email'
    }
});

function passwordConfirm(value)
{
    return this.password=value;
}

module.exports =mongoose.model('Login',LoginSchema);