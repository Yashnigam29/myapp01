module.exports = {
  secret: "SomeSecretString",
};